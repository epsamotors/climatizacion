<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Whatsapp-floating-button</title>
  
  
  
      <link rel="stylesheet" href="style.css">

  
</head>

<body>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=12132837597&text=Hola,%20en%20que%20podemos%20ayudarte" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
  
  

</body>

</html>