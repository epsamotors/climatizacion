<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>    
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <title>CLIMATIZACION</title>

<!--

Breezed Template

https://templatemo.com/tm-543-breezed

-->
    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/templatemo-breezed.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/owl-carousel.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/whatsapp.css')); ?>">




    <style>
        .container1 {
            max-width: 820px;
            margin: 0px auto;
            margin-top: 50px;
        }
        .comment {
            float: left;
            width: 100%;
            height: auto;
        }
        .commenter {
            float: left;
        }
        .commenter img {
            width: 35px;
            height: 35px;
        }
        .comment-text-area {
            float: left;
            width: 100%;
            height: auto;
        }

        .textinput {
            float: left;
            width: 100%;
            min-height: 75px;
            outline: none;
            resize: none;
            border: 1px solid grey;
        }
    </style>
    </head>
    
    <body>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<a href="https://api.whatsapp.com/send?phone=12132837597&text=Hola,%20en%20que%20podemos%20ayudarte" class="float" target="_blank">
	<i class="fa fa-whatsapp my-float"></i></a>  
  
    
    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->
    
    
    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="<?php echo e(url('/servicios1')); ?>" class="logo"><img src="images/logo.png" width="90px"/>

</a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
                            <li class="scroll-to-section"><a href="#about">Acerca de nosotros</a></li>
                            <li class="scroll-to-section"><a href="<?php echo e(url('/servicios3')); ?>">Servicios</a></li>
                            
                            <li class="scroll-to-section"><a href="#contact-us">Contactenos</a></li> 
                            <li class="scroll-to-section"><a href="<?php echo e(url('/login')); ?>">INGRESAR</a></li>
                            
                        </ul>        
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->
    
    <!-- ***** Search Area ***** -->
    <div id="search">
        <button type="button" class="close">×</button>
        <form id="contact" action="#" method="get">
            <fieldset>
                <input type="search" name="q" placeholder="SEARCH KEYWORD(s)" aria-label="Search through site content">
            </fieldset>
            <fieldset>
                <button type="submit" class="main-button">Search</button>
            </fieldset>
        </form>
    </div>

    <!-- ***** Main Banner Area Start ***** -->
    <div class="main-banner header-text" id="top">
        <div class="Modern-Slider">
          <!-- Item -->
          <?php $__currentLoopData = $carruseles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrusel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="item">
            <div class="img-fill">
                <img src="<?php echo e(asset('storage').'/'.$carrusel->urlimagen_carru); ?>" width="1200px" height="650px">
                <div class="text-content">
                    <h5 style="font-family: 'Merriweather', serif;"><?php echo e($carrusel->descripcion_carru); ?></h5>
                  
           
                </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- // Item -->
          <!-- Item -->
       
          <!-- // Item -->
          <!-- Item -->
    
          <!-- // Item -->
        </div>
    </div>
    <div class="scroll-down scroll-to-section"><a href="#about"><i class="fa fa-arrow-down"></i></a></div>
    <br><br>


    <?php echo $__env->yieldContent('content'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\climatizacion\resources\views/layouts/tema.blade.php ENDPATH**/ ?>